﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HtmlAgilityPack;
using System.Transactions;
using System.IO;
using TTSASrapingConsol.DAL;
using System.Text.RegularExpressions;
using TTSASrapingConsol.Core;
using System.Net;
using System.Globalization;
using System.Data.Entity.Validation;
using TTSASrapingConsol.Modal;
using Newtonsoft.Json;

namespace TTSASrapingConsol
{
    public class SaveEvent
    {
        IRepository<Event> _repository = new Repository<Event>();
        IRepository<Country> _repositoryCountry = new Repository<Country>();
        IRepository<City> _repositoryCity = new Repository<City>();
        IRepository<Organizer> _repositorOrganizer = new Repository<Organizer>();
        IRepository<Category> _repositoryCategory = new Repository<Category>();

        //public static string Uname = "EM_Green_Temp";
        //public static string Pwd = "ddxX132*";
        // public static string ftppath = "ftp://em.justgreen.in/upload/";
        //public static string Savepath = "http://em.justgreen.in/upload/";

        //public static string ftppath = "ftp://103.250.184.127/myeventmasters.com/upload/";
        public static string ftppath = "ftp://132.148.153.131/httpdocs/upload/";
        public static string Savepath = "https://myeventmasters.com/upload/";
        public static string Uname = "em_ftp";//"em_upload";
        public static string Pwd = "wWfm6^58";//"qgDv02^5*";

        public int saveEvent(string eventurl)
        {
            using (var scope = new TransactionScope(TransactionScopeOption.Required, new System.TimeSpan(0, 15, 0)))
            {
                try
                {
                    if (eventurl != null)
                    {
                        Console.WriteLine("Scraping of " + eventurl + " Started.");
                        Logs.LogError("Scraping of " + eventurl + " Started.");
                        String Data = GetURLData(eventurl);
                        HtmlWeb eventWeb = new HtmlWeb();
                        HtmlDocument eventDocument = new HtmlDocument();
                        eventDocument.LoadHtml(Data);

                        HtmlWeb mediapageWeb = new HtmlWeb();
                        HtmlDocument mediapageDocument;

                        using (var ctx = new TTSADBEntities())
                        {
                            Event SaveEvent = new Event();

                            Logs.LogError("Scraping event name");
                            if (eventDocument.DocumentNode.SelectNodes("//h1") != null && eventDocument.DocumentNode.SelectNodes("//h1").ToArray().Count() == 1)
                            {
                                SaveEvent.Name = eventDocument.DocumentNode.SelectNodes("//h1").ToArray()[0].InnerText;
                                SaveEvent.Name = System.Net.WebUtility.HtmlDecode(SaveEvent.Name);

                                if (SaveEvent.Name != null && !ctx.Event.Any(m => m.Name.ToLower() == SaveEvent.Name.Trim().ToLower()))
                                {
                                    #region Save Event
                                    //if (eventDocument.DocumentNode.SelectNodes("//div [@itemprop='image']") != null &&
                                    //    eventDocument.DocumentNode.SelectNodes("//div [@itemprop='image']").ToArray().Count() > 0 &&
                                    //    eventDocument.DocumentNode.SelectNodes("//div [@itemprop='image']").ToArray()[0] != null &&
                                    //    eventDocument.DocumentNode.SelectNodes("//div [@itemprop='image']").ToArray()[0].ChildNodes != null &&
                                    //     eventDocument.DocumentNode.SelectNodes("//div [@itemprop='image']").ToArray()[0].ChildNodes.ToArray()[0] != null &&
                                    //   eventDocument.DocumentNode.SelectNodes("//div [@itemprop='image']").ToArray()[0].ChildNodes.ToArray()[0].Attributes.ToArray().Count() > 0 &&
                                    //    eventDocument.DocumentNode.SelectNodes("//div [@itemprop='image']").ToArray()[0].ChildNodes.ToArray()[0].Attributes[2].Value != null)
                                    //{
                                    //    var url = eventDocument.DocumentNode.SelectNodes("//div [@itemprop='image']").ToArray()[0].ChildNodes.ToArray()[0].Attributes[2].Value;
                                    //    SaveEvent.Img_Url = url;//eventDocument.DocumentNode.SelectNodes("//div [@itemprop='image']").ToArray()[0].ChildNodes.ToArray()[0].Attributes[2].Value;
                                    //}

                                    //event_type = 1 - Trade
                                    //event_type = 2 - conference
                                    //save event type Trade or conference
                                    if (eventDocument.DocumentNode.SelectNodes("//span[@class='label label-success me-1 fs-12 rounded-2']") != null && eventDocument.DocumentNode.SelectNodes("//span[@class='label label-success me-1 fs-12 rounded-2']").Count > 0)
                                    {
                                        Logs.LogError("Scraping event type");
                                        if (eventDocument.DocumentNode.SelectNodes("//span[@class='label label-success me-1 fs-12 rounded-2']").ToArray()[0].InnerHtml.Contains("Trade Show"))
                                        {
                                            SaveEvent.event_type = 1;
                                        }
                                        else if (eventDocument.DocumentNode.SelectNodes("//span[@class='label label-success me-1 fs-12 rounded-2']").ToArray()[0].InnerHtml.Contains("Conference"))
                                        {
                                            SaveEvent.event_type = 2;
                                        }
                                        Logs.LogError("Scraping event type done");
                                    }

                                    ////if (eventDocument.DocumentNode.SelectNodes("//span[@class='label bg-orange fs-12 rounded-2']") != null && eventDocument.DocumentNode.SelectNodes("//span[@class='label bg-orange fs-12 rounded-2']").Count > 0)
                                    ////{
                                    ////    Logs.LogError("Scraping event type");
                                    ////    if (eventDocument.DocumentNode.SelectNodes("//span[@class='label bg-orange fs-12 rounded-2']").ToArray()[0].InnerHtml.Contains("Featured"))
                                    ////    {
                                    ////        SaveEvent.IsFeatured = 1;
                                    ////    }
                                    ////    else 
                                    ////    {
                                    ////        SaveEvent.IsFeatured = 0;
                                    ////    }
                                    ////    Logs.LogError("Scraping event type done");
                                    ////}


                                    //Description
                                    Logs.LogError("Scraping description");
                                    if (eventDocument.DocumentNode.SelectNodes("//p[@class='mng text-break fs-14']") != null && eventDocument.DocumentNode.SelectNodes("//p[@class='mng text-break fs-14']").ToArray().Count() > 0)
                                        SaveEvent.AboutDetails = System.Net.WebUtility.HtmlDecode(eventDocument.DocumentNode.SelectNodes("//p[@class='mng text-break fs-14']").ToArray()[0].InnerHtml);
                                    Logs.LogError("Scraping description done");

                                    Logs.LogError("Scraping Startdate/EndDate");
                                    if (eventDocument.DocumentNode.SelectNodes("//script[@type='application/ld+json']") != null)
                                    {
                                        var jsstr = eventDocument.DocumentNode.SelectNodes("//script[@type='application/ld+json']");
                                        if (jsstr != null && jsstr.ToArray()[0].InnerText != null)
                                        {
                                            String strSource = jsstr.ToArray()[0].InnerText;
                                            var EventJSobject = JsonConvert.DeserializeObject<_10timesEvent>(strSource);
                                            if (EventJSobject != null && EventJSobject.startDate != null && EventJSobject.startDate != "")
                                            {
                                                SaveEvent.StartDate = DateTime.ParseExact(EventJSobject.startDate, "yyyy-MM-dd", CultureInfo.InvariantCulture);
                                            }
                                            if (EventJSobject != null && EventJSobject.endDate != null && EventJSobject.endDate != "")
                                            {
                                                SaveEvent.EndDate = DateTime.ParseExact(EventJSobject.endDate, "yyyy-MM-dd", CultureInfo.InvariantCulture);
                                            }
                                        }
                                    }
                                    else
                                    {
                                        scope.Dispose();
                                        Console.WriteLine("No event startdate & Enddate found");
                                        return 2;// 2= saved
                                    }
                                    Logs.LogError("Scraping Startdate/Enddate done");

                                    Logs.LogError("Scraping address");
                                    if (eventDocument.DocumentNode.SelectNodes("//input[@id='venueName']") != null && eventDocument.DocumentNode.SelectNodes("//input[@id='venueName']").ToArray().Count() > 0
                                       && eventDocument.DocumentNode.SelectNodes("//input[@id='venueName']").ToArray()[0].Attributes["value"] != null
                                        && eventDocument.DocumentNode.SelectNodes("//input[@id='venueName']").ToArray()[0].Attributes["value"].Value != null)
                                        SaveEvent.VenueName = System.Net.WebUtility.HtmlDecode(eventDocument.DocumentNode.SelectNodes("//input[@id='venueName']").ToArray()[0].Attributes["value"].Value);
                                    Logs.LogError("Scraping address done");

                                    Logs.LogError("Scraping event latitude");
                                    if (eventDocument.DocumentNode.SelectNodes("//span[@id='event_latitude']") != null && eventDocument.DocumentNode.SelectNodes("//span[@id='event_latitude']").ToArray().Count() == 1)
                                        SaveEvent.event_latitude = decimal.Parse(eventDocument.DocumentNode.SelectNodes("//span[@id='event_latitude']").ToArray()[0].InnerHtml, CultureInfo.InvariantCulture);
                                    Logs.LogError("Scraping event latitude done");

                                    Logs.LogError("Scraping event longitude");
                                    if (eventDocument.DocumentNode.SelectNodes("//span[@id='event_longude']") != null && eventDocument.DocumentNode.SelectNodes("//span[@id='event_longude']").ToArray().Count() == 1)
                                        SaveEvent.event_longude = decimal.Parse(eventDocument.DocumentNode.SelectNodes("//span[@id='event_longude']").ToArray()[0].InnerHtml, CultureInfo.InvariantCulture);
                                    Logs.LogError("Scraping event longitude done");

                                    //AttendeeFees - Size, Exhibitor Size, Timings & Event/Show Seniority

                                    Logs.LogError("Scraping event visitors");
                                    if (eventDocument.DocumentNode.SelectNodes(" //td [@id='visitors'] //span") != null &&
                                       eventDocument.DocumentNode.SelectNodes(" //td [@id='visitors'] //span").ToArray().Count() > 0)
                                    {
                                        var VisitorTD = eventDocument.DocumentNode.SelectNodes(" //td [@id='visitors'] //span")[0].InnerText;
                                        if (VisitorTD != null && VisitorTD!="")
                                            SaveEvent.AttendanceSize = VisitorTD;

                                    }
                                    Logs.LogError("Scraping event visitors done");

                                    Logs.LogError("Scraping event exhibitor");
                                    if (eventDocument.DocumentNode.SelectNodes(" //td [@id='exhibitors'] //span") != null &&
                                       eventDocument.DocumentNode.SelectNodes(" //td [@id='exhibitors'] //span").ToArray().Count() > 0)
                                    {
                                        var ExhibitorTD = eventDocument.DocumentNode.SelectNodes(" //td [@id='exhibitors'] //span")[0].InnerText;
                                        if (ExhibitorTD != null && ExhibitorTD != "")
                                            SaveEvent.ExhibitorsSize = ExhibitorTD;

                                    }
                                    Logs.LogError("Scraping event exhibitor done");

                                    //Timings
                                    Logs.LogError("Scraping event timing");
                                    if (eventDocument.DocumentNode.SelectNodes(" //tr [@id='hvrout1'] //td") != null && eventDocument.DocumentNode.SelectNodes("//tr [@id='hvrout1'] //td").ToArray().Count() > 0
                                    && eventDocument.DocumentNode.SelectNodes("//tr [@id='hvrout1'] //td").Where(m => m.InnerHtml.Contains("Timings")) != null)
                                    {
                                        Logs.LogError("Scraping event timing inside");
                                        var Timing = eventDocument.DocumentNode.SelectNodes(" //tr [@id='hvrout1'] //td").Where(m => m.InnerHtml.Contains("Timings")).ToArray();
                                        if (Timing != null && Timing.Count() > 0 && Timing[0].NextSibling != null)
                                        {
                                            var timingtable = Timing[0].InnerText;

                                            if (timingtable != "" && timingtable != null)
                                                SaveEvent.Timing = timingtable.Trim().TrimEnd(',');




                                            ////var timingtable = Timing[0].NextSibling.ChildNodes;
                                            ////if (timingtable != null && timingtable.Count > 0)
                                            ////{

                                            ////    string tmpStr = "";
                                            ////    string tmpdate = "";
                                            ////    string tmpTiming = "";
                                            ////    foreach (var temptiminTr in timingtable)
                                            ////    {
                                            ////        tmpdate = "";
                                            ////        tmpTiming = "";
                                            ////        tmpdate = temptiminTr.ChildNodes[0].InnerText;
                                            ////        if (temptiminTr.ChildNodes.Count == 2 && temptiminTr.ChildNodes[1].InnerText != null &&
                                            ////            temptiminTr.ChildNodes[1].ChildNodes != null && temptiminTr.ChildNodes[1].ChildNodes.Count > 1 &&
                                            ////            temptiminTr.ChildNodes[1].ChildNodes[0].InnerText != null)
                                            ////        {
                                            ////            tmpTiming += " " + temptiminTr.ChildNodes[1].ChildNodes[0].InnerText;
                                            ////        }
                                            ////        if (tmpdate != "" && tmpdate != null)
                                            ////            tmpStr += tmpdate;
                                            ////        if (tmpTiming != "" && tmpTiming != null)
                                            ////            tmpStr += " " + tmpTiming + ", ";
                                            ////        else
                                            ////            tmpStr += " " + tmpTiming + ", ";
                                            ////    }
                                            ////    if (tmpStr != "" && tmpStr != null)
                                            ////        SaveEvent.Timing = tmpStr.Trim().TrimEnd(',');


                                            ////}

                                        }
                                        Logs.LogError("Scraping event timing inside done");
                                    }
                                    Logs.LogError("Scraping event timing done");

                                    if (eventDocument.DocumentNode.SelectNodes(" //section [@class='box fs-14'] //h2") != null && eventDocument.DocumentNode.SelectNodes(" //section [@class='box fs-14'] //h2").ToArray().Count() > 0)
                                    {

                                        //Past Editions
                                        Logs.LogError("Scraping event past edition");
                                        if (eventDocument.DocumentNode.SelectNodes(" //section [@class='box fs-14'] //h2").Where(m => m.InnerHtml.Contains("Editions")) != null)
                                        {
                                            Logs.LogError("Scraping event past edition inside");
                                            var PastEditions = eventDocument.DocumentNode.SelectNodes(" //section [@class='box fs-14'] //h2").Where(m => m.InnerHtml.Contains("Editions")).ToArray();
                                            if (PastEditions != null && PastEditions.Count() > 0 && PastEditions[0].NextSibling != null)
                                            {
                                                var lastevents = PastEditions[0].NextSibling.ChildNodes;
                                                if (lastevents != null && lastevents.Count > 0 && lastevents[0].ChildNodes != null && lastevents[0].ChildNodes.Count > 0)
                                                {
                                                    string templastdetails = "";
                                                    foreach (var itdtds in lastevents)
                                                    {
                                                        var tds = itdtds.ChildNodes;

                                                        foreach (var td in tds)
                                                        {
                                                            if (td != null && td.ChildNodes.Count > 0)
                                                            {
                                                                templastdetails += td.ChildNodes[0].InnerText;
                                                                if (td.ChildNodes.Count >= 2 && td.ChildNodes[1] != null && td.ChildNodes[1].InnerText != null)
                                                                {
                                                                    templastdetails += " " + td.ChildNodes[1].InnerText + "|";
                                                                }
                                                                else
                                                                {
                                                                    templastdetails += "|";
                                                                }
                                                            }
                                                        }
                                                        if (templastdetails != null && templastdetails != "")
                                                            SaveEvent.PastEditions = templastdetails;
                                                    }
                                                }
                                            }
                                            Logs.LogError("Scraping event past edition inside done");
                                        }
                                        Logs.LogError("Scraping event past edition done");

                                        //Attendee Fees
                                        Logs.LogError("Scraping event attendee fees");
                                        if (eventDocument.DocumentNode.SelectNodes(" //section [@class='box fs-14'] //h2").Where(m => m.InnerHtml.Contains("Entry Fees & Tickets") || m.InnerHtml.Contains("Entry Fees") || m.InnerHtml.Contains("Tickets")) != null)
                                        {
                                            Logs.LogError("Scraping event attendee fees inside");
                                            var Fees = eventDocument.DocumentNode.SelectNodes(" //section [@class='box fs-14'] //h2").Where(m => m.InnerHtml.Contains("Entry Fees & Tickets") || m.InnerHtml.Contains("Entry Fees") || m.InnerHtml.Contains("Tickets")).ToArray();

                                            if (Fees.Count() == 1 && Fees[0] != null && Fees[0].NextSibling != null && Fees[0].NextSibling.ChildNodes.Count() > 0 && Fees[0].NextSibling.ChildNodes[0] != null)
                                            {
                                                string AllFees = "";
                                                string Feedetails = "";

                                                foreach (var itmRow in Fees[0].NextSibling.ChildNodes.ToArray())
                                                {
                                                    if (itmRow != null && itmRow.ChildNodes.Count() > 0)
                                                    {
                                                        Feedetails = "";
                                                        if (itmRow.ChildNodes.ToArray()[0].InnerText != null && itmRow.ChildNodes.ToArray()[0].InnerText != "")
                                                        {
                                                            //Amount
                                                            Feedetails = Regex.Replace(itmRow.ChildNodes.ToArray()[0].InnerText, @"\t|\n|\r", "").ToString().Trim();
                                                        }

                                                        if (itmRow.ChildNodes.ToArray().Count() == 2 && itmRow.ChildNodes.ToArray()[1].ChildNodes != null && itmRow.ChildNodes.ToArray()[1].ChildNodes.Count > 0)
                                                        {
                                                            //Details like booth - Registration Fees
                                                            if (itmRow.ChildNodes.ToArray()[1].ChildNodes.Count > 0 &&
                                                                itmRow.ChildNodes.ToArray()[1].ChildNodes.ToArray()[0].InnerText != null && itmRow.ChildNodes.ToArray()[1].ChildNodes.ToArray()[0].InnerText != "")
                                                                Feedetails += " " + itmRow.ChildNodes.ToArray()[1].ChildNodes.ToArray()[0].InnerText;

                                                            if (itmRow.ChildNodes.ToArray()[1].ChildNodes.Count > 1 &&
                                                                itmRow.ChildNodes.ToArray()[1].ChildNodes.ToArray()[1].InnerText != null && itmRow.ChildNodes.ToArray()[1].ChildNodes.ToArray()[1].InnerText != "")
                                                                Feedetails += " (" + itmRow.ChildNodes.ToArray()[1].ChildNodes.ToArray()[1].InnerText + ")";
                                                        }
                                                        if (Feedetails != "")
                                                            AllFees += Feedetails + "|";

                                                    }
                                                }

                                                // string Feestr = Regex.Replace(Fees[0].NextSibling.ChildNodes[0].ChildNodes[0].InnerText, @"\t|\n|\r", "");
                                                if (AllFees != null)
                                                    SaveEvent.EntryFeesnTickets = AllFees.Trim().TrimEnd('|');
                                            }
                                            Logs.LogError("Scraping event attendee fees inside done");
                                        }
                                        Logs.LogError("Scraping event attendee fees done");
                                    }

                                    //Country:
                                    Logs.LogError("Scraping event country");
                                    if (eventDocument.DocumentNode.SelectNodes("//input[@id='countryName']") != null &&
                                        eventDocument.DocumentNode.SelectNodes("//input[@id='countryName']").ToArray().Count() > 0 &&
                                        eventDocument.DocumentNode.SelectNodes("//input[@id='countryName']").ToArray()[0].Attributes["value"].Value != null)
                                    {
                                        string strCountry = eventDocument.DocumentNode.SelectNodes("//input[@id='countryName']").ToArray()[0].Attributes["value"].Value;
                                        //save Country
                                        #region Country
                                        if (!string.IsNullOrEmpty(strCountry))
                                        {
                                            Country objCountry = ctx.Country.Where(m => m.Name.ToLower() == strCountry.Trim().ToLower()).FirstOrDefault();
                                            if (objCountry == null)
                                            {

                                                objCountry = new Country()
                                                {
                                                    Name = strCountry,
                                                    IsActive = true,
                                                    CreatedDate = DateTime.UtcNow

                                                };

                                                _repositoryCountry.Add(objCountry);
                                                _repositoryCountry.SaveChanges();

                                            }
                                            if (objCountry.CountryId > 0)
                                            {
                                                SaveEvent.CountryId = objCountry.CountryId;
                                            }
                                            #endregion
                                        }

                                    }
                                    Logs.LogError("Scraping event country");

                                    //City
                                    Logs.LogError("Scraping event city");
                                    if (eventDocument.DocumentNode.SelectNodes("//input[@id='cityName']") != null &&
                                        eventDocument.DocumentNode.SelectNodes("//input[@id='cityName']").ToArray().Count() > 0 &&
                                        eventDocument.DocumentNode.SelectNodes("//input[@id='cityName']").ToArray()[0].Attributes["value"].Value != null)
                                    {
                                        string strCity = eventDocument.DocumentNode.SelectNodes("//input[@id='cityName']").ToArray()[0].Attributes["value"].Value;
                                        //save City
                                        #region City
                                        if (!string.IsNullOrEmpty(strCity))
                                        {
                                            City objCity = ctx.City.Where(m => m.Name.ToLower() == strCity.Trim().ToLower()).FirstOrDefault();
                                            if (objCity == null)
                                            {
                                                int CountryId = (int)SaveEvent.CountryId;
                                                objCity = new City()
                                                {
                                                    Name = strCity,
                                                    CountryId = CountryId,
                                                    IsActive = true,
                                                    CreatedDate = DateTime.UtcNow

                                                };
                                                _repositoryCity.Add(objCity);
                                                _repositoryCity.SaveChanges();

                                            }
                                            if (objCity.CityId > 0)
                                            {
                                                SaveEvent.CityId = objCity.CityId;
                                            }
                                        }
                                        #endregion
                                    }
                                    Logs.LogError("Scraping event city done");

                                    //Orgazizer
                                    Logs.LogError("Scraping event organizer");

                                    if (eventDocument.DocumentNode.SelectNodes("//tr [@id='organzr'] //h3") != null &&
                                      eventDocument.DocumentNode.SelectNodes("//tr [@id='organzr']//h3").ToArray().Count() > 0)
                                    {
                                        //var organizer = eventDocument.DocumentNode.SelectNodes("//tr [@id='organzr']//h3").Where(a => a.InnerHtml.Contains("Organizer")).ToArray()[0];

                                        var organizer = "";
                                        if (eventDocument.DocumentNode.SelectNodes("//tr [@id='organzr']//h3//a") != null) {
                                            organizer = eventDocument.DocumentNode.SelectNodes("//tr [@id='organzr']//h3//a")[0].InnerHtml;
                                        }
                                        else if(eventDocument.DocumentNode.SelectNodes("//tr [@id='organzr']//h3") !=null)
                                        {
                                            organizer = eventDocument.DocumentNode.SelectNodes("//tr [@id='organzr']//h3")[0].InnerText;
                                        }
                                        
                                        string strOrganizer = "";
                                        //if (organizer != null && organizer.NextSibling.NextSibling.NextSibling.NextSibling.ChildNodes.Count() > 0)
                                        //    strOrganizer = System.Net.WebUtility.HtmlDecode(organizer.NextSibling.NextSibling.NextSibling.NextSibling.ChildNodes[0].InnerHtml);

                                        //save Orgazizer
                                        #region Orgazizer
                                        if (!string.IsNullOrEmpty(organizer))
                                        {
                                            Organizer objOrgazizer = ctx.Organizer.Where(m => m.Name.ToLower() == strOrganizer.Trim().ToLower()).FirstOrDefault();
                                            if (objOrgazizer == null)
                                            {

                                                objOrgazizer = new Organizer()
                                                {
                                                    Name = strOrganizer,
                                                    IsActive = true,
                                                    CreatedDate = DateTime.UtcNow

                                                };
                                                _repositorOrganizer.Add(objOrgazizer);
                                                _repositorOrganizer.SaveChanges();

                                            }
                                            if (objOrgazizer.OrganizerId > 0)
                                            {
                                                SaveEvent.OrganizerId = objOrgazizer.OrganizerId;
                                            }
                                        }
                                        #endregion
                                    }
                                    Logs.LogError("Scraping event organizer done");

                                    //Category
                                    Logs.LogError("Scraping event category");
                                    if (eventDocument.DocumentNode.SelectNodes("//ol") != null &&
                                     eventDocument.DocumentNode.SelectNodes("//ol //span[@itemprop='name']").ToArray().Count() > 0)
                                    {
                                        string strCategory = null;
                                        if (eventDocument.DocumentNode.SelectNodes("//ol //span[@itemprop='name']").ToArray()[2] != null)
                                            strCategory = System.Net.WebUtility.HtmlDecode(eventDocument.DocumentNode.SelectNodes("//ol //span[@itemprop='name']").ToArray()[2].InnerHtml);
                                        strCategory = System.Net.WebUtility.HtmlDecode(strCategory);
                                        //save Category
                                        #region Category
                                        if (!string.IsNullOrEmpty(strCategory))
                                        {
                                            Category objcategory = ctx.Category.Where(m => m.Name.ToLower() == strCategory.Trim().ToLower()).FirstOrDefault();
                                            if (objcategory == null)
                                            {

                                                objcategory = new Category()
                                                {
                                                    Name = strCategory,
                                                    IsActive = true,
                                                    CreatedDate = DateTime.UtcNow

                                                };
                                                _repositoryCategory.Add(objcategory);
                                                _repositoryCategory.SaveChanges();

                                            }
                                            if (objcategory.CategoryId > 0)
                                            {
                                                SaveEvent.CategoryId = objcategory.CategoryId;
                                            }
                                        }
                                        #endregion
                                    }
                                    Logs.LogError("Scraping event category done");

                                    SaveEvent.IsActive = true;
                                    SaveEvent.CreatedDate = DateTime.UtcNow;

                                    if (SaveEvent.StartDate != null && SaveEvent.EndDate != null && SaveEvent.OrganizerId > 0)
                                    {

                                        _repository.Add(SaveEvent);
                                        _repository.SaveChanges();
                                    }

                                    #endregion

                                    #region Save Event Icon/logo
                                    //Event_Image = 0,
                                    //Event_Video = 1,
                                    //Event_BookingForm = 3,
                                    //CG_Booth_Booking = 4,
                                    //shofixx_Booth_Booking = 5,
                                    //Event_Icon = 6

                                    Logs.LogError("Scraping event images");
                                    if (eventDocument.DocumentNode.SelectNodes("//*[contains(@class,'img-thumbnail')]") != null &&
                                        eventDocument.DocumentNode.SelectNodes("//*[contains(@class,'img-thumbnail')]").ToArray().Count() > 0 &&
                                       eventDocument.DocumentNode.SelectNodes("//*[contains(@class,'img-thumbnail')]").ToArray()[0].Attributes["src"] != null)
                                    {
                                        try
                                        {
                                            Logs.LogError("Scraping event images inside");
                                            string imageUrl = eventDocument.DocumentNode.SelectNodes("//*[contains(@class,'img-thumbnail')]").ToArray()[0].Attributes["src"].Value;
                                            string fileName = Path.GetFileName(eventDocument.DocumentNode.SelectNodes("//*[contains(@class,'img-thumbnail')]").ToArray()[0].Attributes["src"].Value);
                                            byte[] imageBytes;
                                            HttpWebRequest imageRequest = (HttpWebRequest)WebRequest.Create(imageUrl);
                                            WebResponse imageResponse = imageRequest.GetResponse();

                                            Stream responseStream = imageResponse.GetResponseStream();

                                            using (BinaryReader br = new BinaryReader(responseStream))
                                            {
                                                imageBytes = br.ReadBytes(500000);
                                                br.Close();
                                            }
                                            responseStream.Close();
                                            imageResponse.Close();


                                            FtpWebRequest request = (FtpWebRequest)WebRequest.Create(ftppath + fileName);
                                            request.Method = WebRequestMethods.Ftp.UploadFile;
                                            request.Credentials = new NetworkCredential(Uname, Pwd);
                                            request.ContentLength = imageBytes.Length;
                                            request.UseBinary = true;

                                            Stream requestStream = request.GetRequestStream();
                                            requestStream.Write(imageBytes, 0, imageBytes.Length);
                                            requestStream.Close();

                                            FtpWebResponse response = (FtpWebResponse)request.GetResponse();

                                            Console.WriteLine("Image File Upload status: {0}", response.StatusDescription);
                                            response.Close();

                                            Media objMedia = new Media()
                                            {
                                                EventId = SaveEvent.EventId,
                                                Path = Savepath + fileName,
                                                Type = 6//for Event Icon
                                            };
                                            if (objMedia.EventId > 0)
                                            {
                                                ctx.Media.Add(objMedia);
                                                ctx.SaveChanges();
                                            }
                                            Console.WriteLine("Image File Saved");
                                            Logs.LogError("Scraping event images inside done");
                                            Logs.LogError("Images file saved");
                                        }
                                        catch (WebException ex)
                                        {
                                            Logs.LogError("Images file not saved");
                                            Console.WriteLine("Media File not Saved");
                                            //  String status = ((FtpWebResponse)ex.Response).StatusDescription;

                                        }
                                        catch (Exception ex)
                                        {
                                            Console.WriteLine("Media File not Saved");
                                            Logs.LogError("Images file not saved");
                                        }
                                    }
                                    Logs.LogError("Scraping event images done");
                                    #endregion

                                    #region Save Media
                                    Logs.LogError("Scraping event media");
                                    if (eventDocument.DocumentNode.SelectNodes("//li [@id='photo']") != null)
                                    {
                                        Console.WriteLine("Media Files Found!");
                                        Logs.LogError("Media file found");
                                        //save Media
                                        var MediaData = GetURLData(eventurl + "/photos-videos");
                                        mediapageDocument = new HtmlDocument();
                                        mediapageDocument.LoadHtml(MediaData);
                                        if (mediapageDocument != null && mediapageDocument.DocumentNode.SelectNodes("//*[@class='lazy image img-responsive']") != null && mediapageDocument.DocumentNode.SelectNodes("//*[@class='lazy image img-responsive']").ToArray().Count() > 0)
                                        {
                                            var Medilinks = mediapageDocument.DocumentNode.SelectNodes("//*[@class='lazy image img-responsive']");
                                            for (int i = 0; i < Medilinks.Count; i++)
                                            {
                                                if (Medilinks[i] != null && Medilinks[i].Attributes != null && Medilinks[i].Attributes.Count > 0)
                                                {

                                                    if (Medilinks[i].Attributes[0].Value.Contains("www.youtube.com") || Medilinks[i].Attributes[0].Value.Contains("http://youtu.be/"))
                                                    {
                                                        var regex = @"youtu(?:\.be|be\.com)/(?:.*v(?:/|=)|(?:.*/)?)([a-zA-Z0-9-_]+)";
                                                        var match = Regex.Match(Medilinks[i].Attributes[0].Value, regex, RegexOptions.IgnoreCase);

                                                        if (match.Success)
                                                        {
                                                            //Video
                                                            Media objMedia = new Media()
                                                            {
                                                                EventId = SaveEvent.EventId,
                                                                Path = Medilinks[i].Attributes[0].Value,
                                                                Type = 1
                                                            };
                                                            if (objMedia.EventId > 0)
                                                            {
                                                                ctx.Media.Add(objMedia);
                                                                ctx.SaveChanges();
                                                            }
                                                            Console.WriteLine("Video Saved");
                                                        }
                                                        else
                                                        {
                                                            Console.WriteLine("Invalid url");
                                                        }
                                                    }
                                                    else
                                                    {
                                                        try
                                                        {
                                                            string imageUrl = Medilinks[i].Attributes[0].Value;
                                                            string fileName = Path.GetFileName(imageUrl);
                                                            byte[] imageBytes;
                                                            HttpWebRequest imageRequest = (HttpWebRequest)WebRequest.Create(imageUrl);
                                                            WebResponse imageResponse = imageRequest.GetResponse();

                                                            Stream responseStream = imageResponse.GetResponseStream();

                                                            using (BinaryReader br = new BinaryReader(responseStream))
                                                            {
                                                                imageBytes = br.ReadBytes(500000);
                                                                br.Close();
                                                            }
                                                            responseStream.Close();
                                                            imageResponse.Close();


                                                            FtpWebRequest request = (FtpWebRequest)WebRequest.Create(ftppath + fileName);
                                                            request.Method = WebRequestMethods.Ftp.UploadFile;
                                                            request.Credentials = new NetworkCredential(Uname, Pwd);
                                                            request.ContentLength = imageBytes.Length;
                                                            request.UseBinary = true;

                                                            Stream requestStream = request.GetRequestStream();
                                                            requestStream.Write(imageBytes, 0, imageBytes.Length);
                                                            requestStream.Close();

                                                            FtpWebResponse response = (FtpWebResponse)request.GetResponse();

                                                            Console.WriteLine("Image File Upload status: {0}", response.StatusDescription);
                                                            response.Close();

                                                            Media objMedia = new Media()
                                                            {
                                                                EventId = SaveEvent.EventId,
                                                                Path = Savepath + fileName,
                                                                Type = 0
                                                            };
                                                            if (objMedia.EventId > 0)
                                                            {
                                                                ctx.Media.Add(objMedia);
                                                                ctx.SaveChanges();
                                                            }
                                                            Console.WriteLine("Image File Saved");
                                                            Logs.LogError("Media file saved");
                                                        }
                                                        catch (WebException ex)
                                                        {
                                                            Console.WriteLine("Media File not Saved");
                                                            Logs.LogError("Media file not saved");
                                                            //  String status = ((FtpWebResponse)ex.Response).StatusDescription;

                                                        }
                                                        catch (Exception ex)
                                                        {
                                                            Console.WriteLine("Media File not Saved");
                                                            Logs.LogError("Media file not saved");
                                                        }

                                                    }
                                                }
                                            }
                                            Console.WriteLine("Media File(s) Saved");
                                            Logs.LogError("Media file saved");
                                        }
                                    }
                                    Logs.LogError("Scraping event media done");
                                    #endregion
                                    scope.Complete();

                                    Console.WriteLine("Event Saved");
                                    Logs.LogError("Whole Event saved successfully");
                                    return 1;// 1= Done
                                }
                                else
                                {
                                    scope.Dispose();
                                    Console.WriteLine("Event already Saved");
                                    Logs.LogError("Event already saved");
                                    return 33;// 2= saved
                                }
                            }
                            else
                            {
                                scope.Dispose();
                                Console.WriteLine("No event name found");
                                Logs.LogError("No event name found");
                                return 2;// 2= saved
                            }
                        }
                    }
                    else
                    {
                        scope.Dispose();
                        Console.WriteLine("No url found for Scraping.");
                        Logs.LogError("No url found for Scraping.");
                        return 0;// 0=error
                    }
                }
                catch (DbEntityValidationException e)
                {
                    scope.Dispose();
                    foreach (var eve in e.EntityValidationErrors)
                    {
                        Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                            eve.Entry.Entity.GetType().Name, eve.Entry.State);
                        Logs.LogError("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:" + eve.Entry.Entity.GetType().Name + eve.Entry.State);

                        foreach (var ve in eve.ValidationErrors)
                        {
                            Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                                ve.PropertyName, ve.ErrorMessage);
                            Logs.LogError("Error: \"{1}\"" + ve.ErrorMessage);
                        }
                    }
                    return 0;// 0=error
                }
                catch (Exception ex)
                {
                    scope.Dispose();
                    Console.WriteLine("Exception: Return 10 Repeat :" + ex);
                    Logs.Writelog(ex.ToString());
                    Logs.LogError(ex.ToString());
                    return 10;// 0=error
                }
            }

        }

        public static string GetURLData(string URL)
        {
            try
            {
                HttpWebRequest request = (HttpWebRequest)HttpWebRequest.Create(URL);
                request.AllowWriteStreamBuffering = false;
                request.Timeout = 80000;
                WebResponse response = request.GetResponse();
                Stream stream = response.GetResponseStream();
                StreamReader reader = new StreamReader(stream);
                return reader.ReadToEnd();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception: " + ex);
                Logs.LogError("Exception: " + ex.ToString());
                return "";
            }
        }
    }
}
