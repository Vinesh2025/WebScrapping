﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HtmlAgilityPack;
using TTSASrapingConsol.Core;
using TTSASrapingConsol.DAL;
using System.Globalization;
using System.Text.RegularExpressions;
using System.Net;
using System.Data.Entity.Validation;
using System.IO;
using System.Transactions;
namespace TTSASrapingConsol
{
    class Program
    {
        //public static string Uname = "EM_Green_Temp";
        //public static string Pwd = "ddxX132*";
        // public static string ftppath = "ftp://em.justgreen.in/upload/";
        // public static string Savepath = "http://em.justgreen.in/upload/";
        public static string ftppath = "ftp://myeventmasters.com/upload/";
        public static string Savepath = "https://myeventmasters.com/upload/";
        public static string Uname = "em_upload";
        public static string Pwd = "qgDv02^5*";

        static void Main(string[] args)
        {
            SaveEvent objSaveEvent = new SaveEvent();
            ////////////////////////////////////////Testing debug URL
            var testdebug = objSaveEvent.saveEvent("https://10times.com/e13r-gghf-p619");
            IRepository<Event> _repository = new Repository<Event>();
            IRepository<Country> _repositoryCountry = new Repository<Country>();
            IRepository<City> _repositoryCity = new Repository<City>();
            IRepository<Organizer> _repositorOrganizer = new Repository<Organizer>();
            IRepository<Category> _repositoryCategory = new Repository<Category>();
            Console.WriteLine("Started");
            Logs.LogError("Scraping Started.");
            var inEvent = 0;
            int NoUrl = 0;
            int save = 0;
            int notsave = 0;
            string Maindomain = "http://10times.com";
            List<ScrapUrl> EventPageUrl = new List<ScrapUrl>();
            List<ScrapUrl> SearchPageUrl = new List<ScrapUrl>();
            try
            {
                #region Event links from search pages
                SearchPageUrl.Add(new ScrapUrl() { strUrl = "https://10times.com/education-training" });
                //SearchPageUrl.Add(new ScrapUrl() { strUrl = "http://10times.com/events?&ajax=1&page=2" });
                //SearchPageUrl.Add(new ScrapUrl() { strUrl = "http://10times.com/events?&ajax=1&page=3" });
                //SearchPageUrl.Add(new ScrapUrl() { strUrl = "http://10times.com/events?&ajax=1&page=4" });
                //SearchPageUrl.Add(new ScrapUrl() { strUrl = "http://10times.com/events?&ajax=1&page=5" });
                //SearchPageUrl.Add(new ScrapUrl() { strUrl = "http://10times.com/events?&ajax=1&page=6" });

                Console.WriteLine("Getting Event URL from Search results...");
                HtmlWeb SPweb = new HtmlWeb();
                HtmlDocument SPdocument = new HtmlDocument();
                int result;
                int resultTopEvents;
                for (int j = 0; j < SearchPageUrl.Count; j++)
                {
                    try
                    {
                        var item = SearchPageUrl[j];
                        //Get event link for search pages
                        var ScrapData = GetURLData(item.strUrl);
                        SPdocument.LoadHtml(ScrapData);
                        if (SPdocument.DocumentNode.SelectNodes("//h2 //a[@href]") != null)
                        {
                            for (int i = 0; i < SPdocument.DocumentNode.SelectNodes("//h2 //a[@href]").Count; i++)
                            {
                                HtmlNode SPeventlink = SPdocument.DocumentNode.SelectNodes("//h2 //a[@href]")[i];
                                // Get the value of the HREF attribute
                                string eventUrl = SPeventlink.GetAttributeValue("href", string.Empty);
                                // EventPageUrl.Add(new ScrapUrl() { strUrl = Maindomain + eventUrl });
                                Console.WriteLine("Getting No. Event URL:" + NoUrl);
                                try
                                {
                                    result = objSaveEvent.saveEvent(eventUrl);

                                    if (result == 1)
                                    {
                                        save++;
                                        Console.WriteLine("saved event:" + save);
                                    }
                                    else if (result == 10)// URl not reachable
                                    {
                                        i--;
                                        notsave++;
                                        Console.WriteLine("Not saved event:" + notsave);
                                    }
                                    else
                                    {
                                        notsave++;
                                        Console.WriteLine("Not saved event:" + notsave);
                                    }
                                    NoUrl++;
                                }
                                catch (Exception ex)
                                {
                                    i--;
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        j--;
                    }
                }


                #endregion

                #region Get Top100Event links by industry
                Logs.LogError("Scraping URL industry wise started");
                String Data = GetURLData("https://10times.com/top100");
                HtmlWeb webTop100 = new HtmlWeb();
                HtmlDocument documentTop100 = new HtmlDocument();
                documentTop100.LoadHtml(Data);
                Logs.LogError("Scraping URL industry wise started done");

                if (documentTop100 != null &&
                        documentTop100.DocumentNode.SelectNodes("//select[@id='industry'] //option") != null &&
                        documentTop100.DocumentNode.SelectNodes("//select[@id='industry'] //option").Count > 0)
                {
                    Logs.LogError("Getting Industries URL...");
                    Console.WriteLine("Getting Industries URL...");
                    //Get Industry wise top 100 event list
                    List<ScrapUrl> IndustryUrl = new List<ScrapUrl>();
                    foreach (var item in documentTop100.DocumentNode.SelectNodes("//select[@id='industry'] //option").ToArray())
                    {
                        if (item.Attributes.Count > 0 && item.Attributes[0] != null && item.Attributes[0].Value != null && item.Attributes[0].Value != "")
                        {
                            ScrapUrl objTop100Url = new ScrapUrl() { strUrl = "http://10times.com/top100/" + item.Attributes[0].Value };
                            if (objTop100Url != null && objTop100Url.strUrl != null)
                                IndustryUrl.Add(objTop100Url);
                        }
                    }
                    if (IndustryUrl != null && IndustryUrl.Count > 0)
                    {
                        Console.WriteLine("Getting Each Industry wise Event URL...");
                        Logs.LogError("Getting Each Industries wise Event URL...");
                        for (int j = 0; j < IndustryUrl.Count; j++)
                        {
                            try
                            {
                                var itm = IndustryUrl[j];
                                Logs.LogError("Scraping URL - " + itm.strUrl);
                                String IndustryData = GetURLData(itm.strUrl);
                                HtmlWeb webIndustry = new HtmlWeb();
                                HtmlDocument documentIndustry = new HtmlDocument();
                                documentIndustry.LoadHtml(IndustryData);
                                Logs.LogError("Scraping URL - " + itm.strUrl + " done.");

                                if (documentIndustry != null && documentIndustry.DocumentNode.SelectNodes("//section[@class] //strong //a[@href]") != null &&
                                    documentIndustry.DocumentNode.SelectNodes("//section[@class] //strong //a[@href]").ToArray().Count() > 0)
                                {
                                    //Get event page URL
                                    for (int i = 0; i < documentIndustry.DocumentNode.SelectNodes("//section[@class] //strong //a[@href]").Count; i++)
                                    {
                                        HtmlNode eventlink = documentIndustry.DocumentNode.SelectNodes("//section[@class] //strong //a[@href]")[i];
                                        // Get the value of the HREF attribute
                                        string eventUrl = eventlink.GetAttributeValue("href", string.Empty);
                                        if (!eventUrl.ToLower().Contains("venues") && !eventUrl.ToLower().Contains("organizers"))
                                        {
                                            //EventPageUrl.Add(new ScrapUrl() { strUrl = Maindomain + eventUrl });
                                            //Console.WriteLine("Getting No. Event URL:" + NoUrl);

                                            Logs.LogError("Getting No. Event URL:" + NoUrl);
                                            Console.WriteLine("Getting No. Event URL:" + NoUrl);
                                            try
                                            {
                                                resultTopEvents = objSaveEvent.saveEvent(Maindomain + eventUrl);
                                                if (resultTopEvents == 1)
                                                {
                                                    save++;
                                                    Console.WriteLine("saved event:" + save);
                                                    Logs.LogError("saved event:" + save);
                                                }
                                                else if (resultTopEvents == 10)// URl not reachable
                                                {
                                                    i--;
                                                    notsave++;
                                                    Console.WriteLine("Not saved event:" + notsave);
                                                    Logs.LogError("Not saved event:" + notsave);
                                                }
                                                else if (resultTopEvents == 33)// Already saved
                                                {
                                                    i = i + 5;
                                                    notsave++;
                                                    Console.WriteLine("Not saved event:" + notsave);
                                                }
                                                else
                                                {
                                                    notsave++;
                                                    Console.WriteLine("Not saved event:" + notsave);
                                                    Logs.LogError("Not saved event:" + notsave);
                                                }
                                                NoUrl++;
                                            }
                                            catch (Exception ex)
                                            {
                                                i--;
                                            }
                                        }
                                        else
                                        {
                                            Console.WriteLine("Removed other page URL:" + eventUrl);
                                            Logs.LogError("Removed other page URL:" + eventUrl);
                                        }
                                    }
                                }
                            }
                            catch (Exception ex)
                            {
                                j--;
                            }
                        }
                    }
                }
                #endregion

                #region Get Top100Event links by Country
                Logs.LogError("Scraping URL country wise started");
                HtmlWeb CountryTop100 = new HtmlWeb();
                HtmlDocument DocCountryTop100 = new HtmlDocument();
                DocCountryTop100.LoadHtml(Data);
                Logs.LogError("Scraping URL country wise done");

                //if (DocCountryTop100 != null &&
                //        DocCountryTop100.DocumentNode.SelectNodes("//select[@id='country'] //option") != null &&
                //        DocCountryTop100.DocumentNode.SelectNodes("//select[@id='country'] //option").Count > 0)
                //{

                //    Console.WriteLine("Getting countries URL...");
                //    //Get Country wise top 100 event list
                //    List<ScrapUrl> CountryUrl = new List<ScrapUrl>();
                //    foreach (var item in DocCountryTop100.DocumentNode.SelectNodes("//select[@id='country'] //option").ToArray())
                //    {
                //        if (item.Attributes.Count > 0 && item.Attributes[0] != null && item.Attributes[0].Value != null && item.Attributes[0].Value != "")
                //        {
                //            ScrapUrl objTop100Url = new ScrapUrl() { strUrl = "http://10times.com/top100/" + item.Attributes[0].Value };
                //            if (objTop100Url != null && objTop100Url.strUrl != null)
                //                CountryUrl.Add(objTop100Url);
                //        }
                //    }
                //    if (CountryUrl != null && CountryUrl.Count > 0)
                //    {
                //        Console.WriteLine("Getting Each Country wise Event URL...");
                //        foreach (var itm in CountryUrl)
                //        {
                //            HtmlWeb webIndustry = new HtmlWeb();
                //            HtmlDocument documentIndustry = webIndustry.Load(itm.strUrl);
                //            if (documentIndustry != null && documentIndustry.DocumentNode.SelectNodes("//section[@class] //strong //a[@href]") != null &&
                //                documentIndustry.DocumentNode.SelectNodes("//section[@class] //strong //a[@href]").ToArray().Count() > 0)
                //            {
                //                //Get event page URL

                //                for (int i = 0; i < documentIndustry.DocumentNode.SelectNodes("//section[@class] //strong //a[@href]").Count; i++)
                //                {
                //                    HtmlNode eventlink = documentIndustry.DocumentNode.SelectNodes("//section[@class] //strong //a[@href]")[i];
                //                    // Get the value of the HREF attribute
                //                    string eventUrl = eventlink.GetAttributeValue("href", string.Empty);
                //                    if (!eventUrl.ToLower().Contains("venues") && !eventUrl.ToLower().Contains("organizers"))
                //                    {
                //                        //EventPageUrl.Add(new ScrapUrl() { strUrl = Maindomain + eventUrl });
                //                        //Console.WriteLine("Getting No. Event URL:" + NoUrl);


                //                        Console.WriteLine("Getting No. Event URL:" + NoUrl);
                //                        try
                //                        {
                //                            resultTopEvents = objSaveEvent.saveEvent(Maindomain + eventUrl);
                //                            if (resultTopEvents == 1)
                //                            {
                //                                save++;
                //                                Console.WriteLine("saved event:" + save);
                //                            }
                //                            else if (resultTopEvents == 10)// URl not reachable
                //                            {
                //                                i--;
                //                                notsave++;
                //                                Console.WriteLine("Not saved event:" + notsave);
                //                            }
                //                            else
                //                            {
                //                                notsave++;
                //                                Console.WriteLine("Not saved event:" + notsave);
                //                            }
                //                            NoUrl++;
                //                        }
                //                        catch (Exception ex)
                //                        {
                //                            i--;
                //                        }
                //                    }
                //                    else
                //                    {
                //                        Console.WriteLine("Removed other page URL:" + eventUrl);
                //                    }
                //                }


                //            }
                //        }

                //    }
                //}
                #endregion

                Console.WriteLine("Scraping Done." + inEvent + " Events saved.");
                Logs.LogError("Scraping Done." + inEvent + " Events saved.");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception: " + ex);
                Logs.Writelog(ex.ToString());
                Logs.LogError(ex.ToString());
                //throw;
            }
        }

        public static string GetURLData(string URL)
        {
            try
            {
                HttpWebRequest request = (HttpWebRequest)HttpWebRequest.Create(URL);
                request.AllowWriteStreamBuffering = false;
                request.Timeout = 80000;
                WebResponse response = request.GetResponse();
                Stream stream = response.GetResponseStream();
                StreamReader reader = new StreamReader(stream);
                return reader.ReadToEnd();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception Get URL: " + ex);
                Logs.LogError("Exception Get URL: " + ex.ToString());
                return "";
            }
        }
    }
}
