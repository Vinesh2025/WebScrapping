﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TTSASrapingConsol
{
    public static class Logs
    {
        public static void Writelog(string foLogtxt)
        {
            string strLogText = foLogtxt;

            // Create a writer and open the file:
            StreamWriter log;
            log = new StreamWriter("logfile_"+DateTime.Now.Ticks+".txt");
            // Write to the file:
            log.WriteLine(DateTime.Now);
            log.WriteLine(strLogText);
            log.WriteLine();

            // Close the stream:
            log.Close();
        }

        public static void LogError(string ex)
        {
            try
            {
                string baseLogFolder = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Log");
                string path = string.Format(@"{0}\Errors_{1}.txt", baseLogFolder, DateTime.Today.ToString("dd-MM-yyyy"));
                if (!Directory.Exists(Path.GetDirectoryName(path)))
                {
                    Directory.CreateDirectory(Path.GetDirectoryName(path));
                }
                if (!File.Exists(path))
                {
                    File.Create(path).Close();
                }
                using (StreamWriter w = File.AppendText(path))
                {
                    w.WriteLine("\r\nLog Entry : ");
                    w.WriteLine("{0}", DateTime.Now.ToString(System.Globalization.CultureInfo.InvariantCulture));
                    string err = ex;
                    w.WriteLine(err);
                    w.WriteLine("___________________________________________________________________________");
                    w.WriteLine("");
                    w.Flush();
                    w.Close();
                }
            }
            catch (Exception exc)
            {
                throw exc;
            }
        }
    }
}
