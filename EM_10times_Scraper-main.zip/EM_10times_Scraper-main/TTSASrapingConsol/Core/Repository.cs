﻿using System;
using System.Data.Entity.Infrastructure;
using System.Data.Entity.Validation;
using System.Linq;
using System.Transactions;


namespace TTSASrapingConsol.Core
{
    public class Repository<T> : IRepository<T> where T : class
    {
        private readonly IContext<T> _context;

        public Repository()
        {
            _context = new Context<T>();
        }
        public Repository(IContext<T> context)
        {
            _context = context;
        }

        public T Add(T entity)
        {
            return _context.DbSet.Add(entity);
        }

        public T Remove(T entity)
        {
            return _context.DbSet.Remove(entity);
        }

        public T Update(T entity)
        {
            var updated = _context.DbSet.Attach(entity);
            _context.DbContext.Entry(entity).State = System.Data.EntityState.Modified;
            return updated;
        }

        public T AddUpdate(T entity, int id)
        {
            if (id == 0)
                return _context.DbSet.Add(entity);
            else
            {
                var updated = _context.DbSet.Attach(entity);
                _context.DbContext.Entry(entity).State = System.Data.EntityState.Modified;
                return updated;
            }
        }
        public IQueryable<T> GetAll()
        {
            return _context.DbSet;
        }

        public T Get(object key)
        {
            return _context.DbSet.Find(key);
        }
        public T GetById(int key)
        {
            return _context.DbSet.Find(key);
        }

        public void SaveChanges()
        {
            using (var scope = new TransactionScope())
            {
                try
                {
                    _context.DbContext.SaveChanges();
                    scope.Complete();
                }
                catch (DbEntityValidationException ex)
                {
                    foreach (var validationErrors in ex.EntityValidationErrors)
                    {
                        foreach (var validationError in validationErrors.ValidationErrors)
                        {
                            string message = string.Format("{0}:{1}",
               validationErrors.Entry.Entity.ToString(),
               validationError.ErrorMessage);
                            throw ex;// validationError.PropertyName + " " + validationError.ErrorMessage;
                        }
                    }
                    throw ex;
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
        }

        public void InsertOrUpdate(T entity)
        {
            var updated = _context.DbSet.Attach(entity);
            _context.DbContext.Entry(entity).State = System.Data.EntityState.Modified;

            foreach (DbEntityEntry<T> entry in _context.DbContext.ChangeTracker.Entries<T>()
                                .Where(c => _context.DbContext.Entry(c.Entity).State != System.Data.EntityState.Modified
                                && _context.DbContext.Entry(c.Entity).State != System.Data.EntityState.Unchanged))
            {
                var y = _context.DbContext.Entry(entry.Entity);
                y.State = _context.DbContext.Entry(entry.Entity).State;
                _context.DbContext.Entry(entry.Entity).State = System.Data.EntityState.Modified;
            }
        }
    }
}