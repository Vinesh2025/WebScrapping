﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TTSASrapingConsol.Core
{
    public interface IRepository<T>
    {
        T Add(T entity);
        T Remove(T entity);
        T Update(T entity);
        T AddUpdate(T entity, int id);
        IQueryable<T> GetAll();
        T Get(object key);
        void SaveChanges();
        T GetById(int Id);
        void InsertOrUpdate(T entity);


    }
}