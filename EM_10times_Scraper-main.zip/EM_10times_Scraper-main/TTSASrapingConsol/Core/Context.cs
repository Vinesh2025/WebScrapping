﻿using System.Configuration;
using System.Data.Entity;

namespace TTSASrapingConsol.Core
{
    public class Context<T> : IContext<T> where T : class
    {
        public Context()
        {
            //DbContext = new DbContext("metadata=res://*/DAL.TTSAModel.csdl|res://*/DAL.TTSAModel.ssdl|res://*/DAL.TTSAModel.msl;provider=System.Data.SqlClient;provider connection string='data source=64.71.180.27;initial catalog=TTSADB;user id=ttsaadmin;Connection Timeout=60;password=xQsm79!9;MultipleActiveResultSets=True;App=EntityFramework'");
            
            DbContext = new DbContext("metadata=res://*/DAL.TTSAModel.csdl|res://*/DAL.TTSAModel.ssdl|res://*/DAL.TTSAModel.msl;provider=System.Data.SqlClient;provider connection string='data source=51.75.145.34,49884;initial catalog=EventMasterDB;user id=ttsaadmin;Connection Timeout=60;password=xQsm79!9;MultipleActiveResultSets=True;App=EntityFramework'");
            DbSet = DbContext.Set<T>();
        }

        public System.Data.Entity.DbContext DbContext
        {
            get;
            private set;
        }

        public System.Data.Entity.IDbSet<T> DbSet
        {
            get;
            private set;
        }

        public void Dispose()
        {
            DbContext.Dispose();
        }
    }
}