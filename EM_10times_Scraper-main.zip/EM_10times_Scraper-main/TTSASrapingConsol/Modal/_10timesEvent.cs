﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TTSASrapingConsol.Modal
{
    public class _10timesEvent
    {
        public string startDate { get; set; }
        public string endDate { get; set; }
    }
}
